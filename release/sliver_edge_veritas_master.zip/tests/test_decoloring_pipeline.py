"""
Unit Test Suite: Sobel 3x3 CV Edge Detection, Low-Pass Tremor Filter, & Pigment Database
"""

import math
import pytest

BIOLOGICAL_PIGMENTS = {
    "chlorophyll_a": "#2E7D32",
    "chlorophyll_b": "#81C784",
    "carotenoid_gold": "#FFB300",
    "scute_amber": "#C67D0A",
    "luciferin_glow": "#76FF03",
    "iridophore_cyan": "#00F2FE"
}

def perceptual_luminance(r: int, g: int, b: int) -> int:
    """BT.601 perceptual luminance formula Y = 0.299R + 0.587G + 0.114B"""
    return int(round(0.299 * r + 0.587 * g + 0.114 * b))

def apply_sobel_3x3_pixel(patch):
    gx = (-1 * patch[0][0] + 1 * patch[0][2] +
          -2 * patch[1][0] + 2 * patch[1][2] +
          -1 * patch[2][0] + 1 * patch[2][2])

    gy = (-1 * patch[0][0] - 2 * patch[0][1] - 1 * patch[0][2] +
           1 * patch[2][0] + 2 * patch[2][1] + 1 * patch[2][2])

    magnitude = math.sqrt(gx * gx + gy * gy)
    return min(255, int(magnitude))

def low_pass_filter_step(current_x: float, prev_x: float, alpha: float = 0.25) -> float:
    return alpha * current_x + (1.0 - alpha) * prev_x

def evaluate_precision_secret_unlock(drawn_pixels: int, target_pixels: int) -> bool:
    """Returns True if drawn precision reaches >= 90% threshold for Secret Bio-Glow upgrade."""
    ratio = drawn_pixels / max(1, target_pixels)
    return (ratio * 100) >= 90.0

def test_perceptual_luminance_bt601():
    assert perceptual_luminance(255, 255, 255) == 255
    assert perceptual_luminance(0, 0, 0) == 0
    assert perceptual_luminance(100, 200, 50) == 153

def test_sobel_3x3_gradient():
    patch_vertical_edge = [
        [0, 0, 255],
        [0, 0, 255],
        [0, 0, 255]
    ]
    mag = apply_sobel_3x3_pixel(patch_vertical_edge)
    assert mag > 100

def test_somatic_tremor_filter():
    smoothed = low_pass_filter_step(current_x=100.0, prev_x=0.0, alpha=0.25)
    assert smoothed == 25.0

def test_biological_pigments_database():
    assert "chlorophyll_a" in BIOLOGICAL_PIGMENTS
    assert BIOLOGICAL_PIGMENTS["iridophore_cyan"] == "#00F2FE"

def test_precision_secret_unlock_trigger():
    assert evaluate_precision_secret_unlock(95, 100) is True
    assert evaluate_precision_secret_unlock(50, 100) is False
